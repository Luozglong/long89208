package com.example.android_studio_file

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
